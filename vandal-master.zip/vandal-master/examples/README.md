This directory contains examples of raw `disasm` output which may be used as input to the decompiler.
