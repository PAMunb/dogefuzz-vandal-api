# `test/disasm/`

Any file in this directory with a filename ending in `.dasm` will be
interpreted as raw `disasm` output and automatically used in various unit test
fixtures.
