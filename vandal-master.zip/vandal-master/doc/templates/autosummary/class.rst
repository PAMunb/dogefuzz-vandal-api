{{ fullname }}
{{ underline }}

.. currentmodule:: {{ module }}

.. rubric:: Inheritance Diagram

.. inheritance-diagram:: {{ objname }}

.. rubric:: Class Description

.. autoclass:: {{ objname }}
   :members:
   :undoc-members:
   :show-inheritance:
